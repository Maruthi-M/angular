export class Employee
{
    employees=['a','b','c'];
}