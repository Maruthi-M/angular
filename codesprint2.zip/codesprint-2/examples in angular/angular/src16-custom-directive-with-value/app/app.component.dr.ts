import { Directive, ElementRef, Input, Renderer, AfterViewInit,HostListener } from '@angular/core';

@Directive({ 
     selector: '[cpDefaultTheme]' 
})
export class CPDefaultThemeDirective implements AfterViewInit {
    @Input('cpDefaultTheme') tsize: string;
    constructor(private renderer: Renderer, private elRef: ElementRef) {
    }

    ngAfterViewInit(): void {
       this.elRef.nativeElement.style.color = 'blue';
       this.elRef.nativeElement.style.fontSize = this.tsize+'px';
       this.elRef.nativeElement.value = "fdsfsdfsd";
       console.log('font size is'+this.tsize);
    }		


// Event listeners for element hosting
  // the directive
    @HostListener('mouseenter') onMouseEnter() {
        this.hover(true);
    }

    @HostListener('mouseleave') onMouseLeave() {
        this.hover(false);
    }
  // Event method to be called on mouse enter and on mouse leave
    hover(shouldUnderline: boolean){
        if(shouldUnderline){
        // Mouse enter   
this.renderer.setElementStyle(this.elRef.nativeElement, 'text-decoration', 'underline');
        } else {
    // Mouse leave           
this.renderer.setElementStyle(this.elRef.nativeElement, 'text-decoration', 'none');
        }
    }

} 