import { Component, Input  } from '@angular/core';

@Component({
  selector : 'my-base',
  template: `
    <div>
      I am base component: {{isBase}}?
    </div>
  `
})
export class BaseComponent {
  @Input() isBase: boolean = true;
}