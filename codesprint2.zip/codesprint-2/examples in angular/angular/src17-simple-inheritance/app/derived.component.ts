import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'my-inherited',
  template: `
    <div>
      Base Component {{isBase}}!
    </div>
  `
})
export class DerivedComponent extends BaseComponent {}