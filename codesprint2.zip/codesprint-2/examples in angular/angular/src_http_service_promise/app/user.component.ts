import {Component, OnInit} from '@angular/core';

import {HttpModule}    from '@angular/http';
//import {XHRBackend}        from '@angular/http';

import {Todo}              from './todo';
import {TodoService}       from './todo.service';

@Component({
  selector: 'pr-app',
  providers: [
    HttpModule, 
    TodoService
  ],
  template: `
  <h3>List of Todos:</h3>
  <ul>
    <li *ngFor="#todo of todos">
      <input type="checkbox" />{{ todo.desc }}
    </li>
  </ul>
  <hr />
  <div class="error" *ngIf="errorMessage">{{errorMessage}}</div>
  `,

  styles: ['ul {  }']
})
export class UserComponent {
  
  constructor (private _todoService: TodoService) {}
  
  errorMessage: string;
  
  todos:Todo[];
  
  ngOnInit() { this.getTodos(); }
  
  getTodos() {
    this._todoService.getTodos()
       .then(
         todos => this.todos = todos,
         error => this.errorMessage = <any>error);
  }

}