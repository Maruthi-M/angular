export class Todo {
  constructor(
    public id:number,
    public desc:string,
    public done: boolean) { }
}