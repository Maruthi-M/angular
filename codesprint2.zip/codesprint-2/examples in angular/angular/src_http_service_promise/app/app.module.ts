import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import {HttpModule}    from '@angular/http';
import { UserComponent }  from './user.component';
@NgModule({
  imports:      [BrowserModule, HttpModule],
  declarations: [UserComponent],
  bootstrap:    [UserComponent]
})
export class AppModule { }
  