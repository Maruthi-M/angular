import { Component } from '@angular/core';

@Component({
  selector: 'demo-app',
  templateUrl: './app.component.html'
})


export class AppComponent {
  
somepar:string ="TestPurpose"

}