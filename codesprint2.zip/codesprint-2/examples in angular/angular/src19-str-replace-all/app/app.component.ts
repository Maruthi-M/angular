import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `              
			    Just to test		  
           `
})
export class AppComponent { 
abc:string = "sfds ujfhw uwe";
constructor()
{
	console.log(this.abc.replace(/ /g, ''));
}
}
    