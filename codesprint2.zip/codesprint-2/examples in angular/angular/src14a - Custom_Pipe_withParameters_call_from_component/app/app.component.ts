import { Component } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'remove-spaces-impl',
	template: ` Nothing to display here ` ,
	providers: [FilterData]	
})

export class AppComponent {
	points: string[] = [
		 'aa',
		 'abb',
		 'aaa',
		 'dd' ,
		 'kdsjfhsd'
	];
	
	constructor(private fd: FilterData) {
		console.log("Length is "+this.fd.transform(this.points,"a").length);	
	}
}