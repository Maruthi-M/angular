import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddtocartComponent } from './addtocart/addtocart.component';
const routes: Routes = [
  {path:'addtocart',component:AddtocartComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
/**const routes: Routes = [
  { path:'', component:LoginComponent},
  { path: 'home', component:HomeComponent },  // you must add your component here
  { path: '**', component:PageNotFoundComponent }
]; */