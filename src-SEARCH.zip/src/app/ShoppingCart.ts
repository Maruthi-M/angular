export class ShoppingCart
{
    
    numberofitems:number;
    item:number;
}