import { Component, OnInit,Input } from '@angular/core';
import {Products} from '../Products';
import {SellerserviceService} from '../sellerservice.service';
import { ShoppingCart } from '../ShoppingCart';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor(private productService:SellerserviceService) {}
@Input() 
product:Products;
cart:ShoppingCart=new ShoppingCart();

  ngOnInit(): void {
  }
  addToCart()
{
 
  this.cart.item=this.product.productId;
  this.cart.numberofitems=1;
  console.log("productId......");
 this.productService.addCartItem(this.cart).subscribe(cart=>this.cart=cart);
}
  /*addToCart()
  {
    this.router.navigate(['/addtocart']);
  }
addToCart()
{
 
  this.cart.item=this.product.productId;
  this.cart.numberofitems=this.product.numberOfProducts;
  this.productService.addCartItem(this.cart).subscribe(cart=>this.cart=cart);
}*/

}
/*import { Router } from '@angular/router';
////this.sService.getProductByName(this.productname).subscribe(Product=>this.product=Product);
export class YourComponentClassName implements OnInit {

    constructor(private router: Router) {}

    gotoHome(){
        this.router.navigate(['/home']);  // define your component where you want to go
    }

} 
.ts
import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../Product';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart } from '../Shoopingcart';

@Component({
  selector: 'app-addcart',
  templateUrl: './addcart.component.html',
  styleUrls: ['./addcart.component.css']
})
export class AddcartComponent implements OnInit {


  constructor(private cartService:BuyerServiceService) { }
  @Input()
  i:Product =new Product();
  cart:Cart =new Cart();

  ngOnInit(): void {
    this.cart=new Cart();
  }
  addCart()
  {
    this.cartService.addCart(this.cart).subscribe(cart => this.cart=cart);
  }
  onSubmit(){
    this.cart.productid=this.i.productid;
    this.cart.selerid=this.i.sdetails;
    this.cart.quantity=this.i.quantity;
    this.cart.price=this.i.price;
 this.addCart();
  }

}
ADDCartANgular
.html
<h4>{{i.productid}}</h4> 
       <h4>{{i.productName}}</h4> 
       <h4>{{i.Model}}</h4> 
       <h4>{{i.quantity}}</h4> 


<div style="width: 300px;">
  <form>
    <div class="btn-group">
      <button type="submit" class="btn btn-success" (click)="onSubmit()">Submit</button>
    </div>
  </form>
</div>
....................................
.ts
import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../Product';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart } from '../Shoopingcart';

@Component({
  selector: 'app-addcart',
  templateUrl: './addcart.component.html',
  styleUrls: ['./addcart.component.css']
})
export class AddcartComponent implements OnInit {


  constructor(private cartService:BuyerServiceService) { }
  @Input()
  i:Product =new Product();
  cart:Cart =new Cart();

  ngOnInit(): void {
    this.cart=new Cart();
  }
  addCart()
  {
    this.cartService.addCart(this.cart).subscribe(cart => this.cart=cart);
  }
  onSubmit(){
    this.cart.productid=this.i.productid;
    this.cart.selerid=this.i.sdetails;
    this.cart.quantity=this.i.quantity;
    this.cart.price=this.i.price;
 this.addCart();
  }

}
------------------------------------------------------
display cart items
.html
<div class="container">
    <h2>Striped Rows</h2>
    <p>Cart Items</p>            
    <table class="table table-striped">
      <thead>
        <tr>
            <th>Id</th>
            <th>productid</th>
          <th>quantity</th>
          <th>price</th>
          <th>buyerid</th>
          <th>selerid</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let cart of disCart">
            <td>{{cart.cart_Id}}</td>
          <td>{{cart.productid}}</td>
          <td>{{cart.quantity}}</td>
          <td>{{cart.price}}</td>
          <td>{{cart.user}}</td>
          <td>{{cart.selerid}}</td>
         </tr>

      </tbody>
    </table>
  </div> 
 25  display-cart-items/display-cart-items.component.spec.ts 
@@ -0,0 +1,25 @@
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayCartItemsComponent } from './display-cart-items.component';

describe('DisplayCartItemsComponent', () => {
  let component: DisplayCartItemsComponent;
  let fixture: ComponentFixture<DisplayCartItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayCartItemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayCartItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 29  display-cart-items/display-cart-items.component.ts 
@@ -0,0 +1,29 @@
import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart } from '../Shoopingcart';

@Component({
  selector: 'app-display-cart-items',
  templateUrl: './display-cart-items.component.html',
  styleUrls: ['./display-cart-items.component.css']
})
export class DisplayCartItemsComponent implements OnInit {
  disCart:Cart[];
  constructor(private displaycart:BuyerServiceService) { 

  }

  ngOnInit(): void {

    this.displaycart.displayCartItems()
      .subscribe(disCart => this.disCart = disCart);
      console.log(this.disCart);
     this.user();

  }
  user()
  {
    this.disCart.buyerid=JSON.stringify(this.disCart.user);
  }

}
*/