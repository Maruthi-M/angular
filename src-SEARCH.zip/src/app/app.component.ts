import { Component } from '@angular/core';
import { SellerserviceService } from './sellerservice.service';
import { Products } from './Products';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'projectapp';
  productname:String;
product:Products[];
 
  constructor(private sService:SellerserviceService){
    console.log("construtor invoked");
  }
  mgOnInit()
  {

    
    this.productname="";
  }
  search()
  {
    console.log("method() invoked");
    //console.log(this.product.productId);
    this.sService.getProductByName(this.productname).subscribe(product=>this.product=product);
  }
  //newly added
  

}




























































/*import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import { Product } from '../product';
@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
productname:String;
products: Product[];

  constructor(private dataService: SellerServiceService) { }

  ngOnInit(): void {
   // this.productname="";
  }
  private searchProducts()
  {
    this.dataService.getProductByName(this.productname)
      .subscribe(products => this.products = products);
  }
  onSubmit()
  {
    this.searchProducts();
  }
  

}*/

