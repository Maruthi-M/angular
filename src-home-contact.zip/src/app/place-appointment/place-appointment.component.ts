import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-place-appointment',
  templateUrl: './place-appointment.component.html',
  styleUrls: ['./place-appointment.component.css']
})
export class PlaceAppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
