export class ShoppingCart
{
    numberofitems:number;
    item:any;
}