import { Component, OnInit,Input } from '@angular/core';
import {Product} from '../Product';
import { SellerserviceService } from '../sellerservice.service';
import {Router} from '@angular/router';
import { ShoppingCart } from '../ShoppingCart';


@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor(private productService:SellerserviceService) { 
    console.log("product construtor invoked");
  }
  
  

@Input() 
product: Product;
cart:ShoppingCart;
i:any;

  ngOnInit(): void {
 
  }
addToCart(productId:Number)
{
 // (property) ProductdetailsComponent.product: Product
this.cart.item=this.product.productId;
this.cart.numberofitems=this.product.numberOfProducts;
this.productService.addCartItem(this.cart).subscribe(i=>this.i=i);
// this.productService.addCartItem(this.cart).subscribe(ShoppingCart=>this.cart=ShoppingCart);
}

}
/*import { Router } from '@angular/router';
////this.sService.getProductByName(this.productname).subscribe(Product=>this.product=Product);
export class YourComponentClassName implements OnInit {

    constructor(private router: Router) {}

    gotoHome(){
        this.router.navigate(['/home']);  // define your component where you want to go
    }

} */